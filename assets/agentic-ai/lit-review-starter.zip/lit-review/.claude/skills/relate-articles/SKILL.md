---
name: relate-articles
description: How to relate the article notes to each other and revise synthesis.md. Use after each new pair of notes, and whenever the synthesis needs revising.
---

# Relating the articles · 2026-11-04

The synthesis is the running picture of how the articles relate. Revise it
as new notes arrive; don't start again from scratch. The log shows what each
revision changed, so a reader can see how the picture developed.

## The synthesis

```text
# Synthesis · version N · <date>

Notes included: S01, S02, …

## Where they overlap

## Where they differ

## What only one of them offers

## For using AI

## For teaching AI

## Gaps

## Open questions
```

- **Where they overlap.** Each point names the specific claim at stake, the
  sources involved with page numbers, and the relationship: agrees with,
  extends, applies, parallels or depends on. Say whether the authors make the
  connection themselves, by citing or responding to each other, or whether
  you drew it. Write your own connections as "Read alongside S02, S04 …".
- **Where they differ.** The claim at stake and each position, with pages.
  Say whether it is a real disagreement or a difference of emphasis,
  audience or kind of work.
- **What only one of them offers.** For each source, what it contributes that
  no other source in the set does. Before you call something unique, check
  every other note for it. Revisit this section at every revision; a new
  note can end a claim of uniqueness.
- **For using AI** and **For teaching AI.** What the set as a whole offers
  each, in a short paragraph, citing source IDs.
- **Gaps.** What none of the sources addresses, whose perspective is missing,
  and where the set over-represents one author, venue or field.
- **Open questions.** What you would need to read or check next.

## The log

Append one entry to synthesis-log.md for each revision:

```text
## Version N · <date> · added S0x, S0y

Added: <new points and the notes they came from>
Changed: <points revised, and why>
Weakened or removed: <points that no longer hold, and why>
Now open: <questions the new notes raised>
```

## Rules

- Name the specific claim at stake, not just related titles.
- State a source's own emphasis before saying how it serves the brief. Don't
  recruit a source to a position it doesn't take.
- Don't present a connection you drew as a debate the authors are having.
- Don't let one source stand for a field. Say when sources share an author
  or a venue.
- Don't hunt for agreement. Where you find a convergence, say who might
  disagree.
- Cite source IDs and page numbers from the notes for every point.
- When a new note changes an earlier point, change it and record the change
  in the log. Never drop a point silently.
